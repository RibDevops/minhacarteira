# Alterações — Minha Carteira Digital
### Arquivo de acompanhamento (atualizado a cada sessão)

> **Como usar este arquivo:** sempre que for continuar o trabalho comigo em uma
> nova conversa, envie este arquivo junto (upload) e diga "continue a partir
> daqui". Eu leio o status de cada item e sigo de onde parou. Eu atualizo este
> arquivo a cada mudança concluída — depois de aplicar um patch, salve a
> versão mais nova dele por cima da antiga.

**Última atualização:** 28/07/2026 — sessão de diagnóstico pós-substituição do repositório

---

## ⚠️ Contexto importante desta sessão

O `git pull` mostrou que o repositório remoto (`github.com/RibDevops/minhacarteira`)
foi **substituído por completo** — o histórico agora tem **1 commit só**
(`4be24ba`), sem nenhum dos patches que eu tinha gerado em sessões anteriores
(bugs de segurança, modal de registro rápido, recorrências, sistema de design).

Pelos arquivos que vieram junto (`replit_progress.md`, `RELATORIO_ALTERACOES.md`,
`attached_assets/`), tudo indica que o **Replit Agent** trabalhou no projeto em
paralelo e o resultado foi commitado por cima, apagando o histórico anterior.

**A boa notícia:** o trabalho do Replit Agent foi sério e bem documentado —
implementou criptografia AES-256 nos campos sensíveis, corrigiu XSS via
`json_script`, corrigiu um IDOR em `meta_excluir`, restringiu CRUD de `Tipo` a
staff, validação de senha consistente, proteção contra CSV injection, entre
outras coisas (ver `RELATORIO_ALTERACOES.md` no repo pra lista completa).

**A má notícia:** nenhuma correção/feature que eu tinha implementado antes
sobreviveu (bugs de UX, modal de registro rápido, recorrências, sistema de
design/CSS). Terei que reavaliar cada item nesse código novo e refazer o que
ainda fizer sentido — daí este arquivo existir, pra não perder o controle de
novo se isso voltar a acontecer.

**Recomendação para evitar que isso se repita:** decidir UM lugar como fonte
da verdade (ou só o Replit Agent, ou só eu) e usar o outro apenas para revisão/
consulta — trabalhar com os dois editando e commitando o mesmo repo em
paralelo tende a gerar exatamente esse tipo de perda de trabalho.

---

## 🐛 Bug relatado: "transações do mês não estão listando"

**Causa raiz confirmada** (reproduzi localmente com dados de teste):

A página **"Despesas"** do menu principal aponta para `/transacoes-mes/`
(view `transacoes_mes_view`, template `transacoes_mes.html`). Esse template
**nunca teve uma tabela/lista de transações** — ele só renderiza os cards de
totais e os dois gráficos. Os dados existem (confirmei que os totais batem),
só não há `{% for %}` nenhum para desenhar as linhas.

A lista de verdade (com filtro por tipo/categoria, cards mobile, tudo
funcionando) existe em outro lugar: `/transacoes/` (view `listar_transacoes`,
template `lista_transacoes.html`) — só que o link pra essa página está
**comentado no menu** (`<!-- ... Despesas Filtro ... -->` em `navbar.html`),
então ninguém acha ela.

**Status:** ⬜ Pendente de correção nesta sessão (ver plano abaixo).

---

## 🔁 Páginas duplicadas/sobrepostas (pedido: unificar)

Confirmei **3 páginas**, não 2, cobrindo o mesmo assunto:

| URL | View | Template | O que mostra | Link no menu |
|---|---|---|---|---|
| `/transacoes-mes/` | `transacoes_mes_view` | `transacoes_mes.html` | Totais + 2 gráficos (tipo, categoria). **Sem lista.** | "Despesas" (ativo) |
| `/transacoes/` | `listar_transacoes` | `lista_transacoes.html` | Lista completa + filtros + cards mobile. **Sem gráficos.** | "Despesas Filtro" (comentado, inacessível) |
| `/resumo-categoria/` | `resumo_categoria_view` | `resumo_categoria.html` | Os mesmos 2 gráficos de novo, recalculados na mão. | "Balanço Mensal" (ativo) |

**Plano de unificação:**
1. Fazer de `lista_transacoes.html` (`/transacoes/`) a página única — já tem a
   base mais completa (lista + filtros + mobile).
2. Portar os 2 gráficos de `transacoes_mes.html`/`resumo_categoria.html` pra
   dentro dela.
3. `transacoes_mes_view` e `resumo_categoria_view` passam a ser **redirects**
   para `listar_transacoes` (não quebra favoritos/links salvos).
4. Menu: "Despesas" passa a apontar pra `listar_transacoes`; remover "Despesas
   Filtro" e "Balanço Mensal" (viram a mesma página).

**Status:** ⬜ Pendente de execução nesta sessão.

---

## ✅ O que o Replit Agent já corrigiu neste código (não precisa refazer)

- [x] Segredos reais expostos no Git (`.env` fora do tracking, chaves rotacionadas)
- [x] Criptografia AES-256 em `Transacao.titulo/valor/observacoes` e `Recorrencia` equivalentes
- [x] XSS via `|safe` em gráficos — trocado por `json_script` (6 templates)
- [x] IDOR em `meta_excluir`
- [x] CRUD de `Tipo` restrito a staff
- [x] Validação de senha consistente em todos os formulários
- [x] Proteção contra CSV injection na exportação
- [x] `parse_mes_ano()` centralizado (mesma ideia que eu tinha implementado antes)
- [x] `Calendar.formatday` com `html.escape` (proteção XSS no calendário)

## ⬜ Itens que eu tinha implementado antes e **precisam ser reavaliados/refeitos** neste código

| Item | Status neste código | Ação |
|---|---|---|
| Modal de registro rápido (FAB) | Não verificado ainda | ⬜ Conferir se existe; se não, reimplementar |
| Recorrências (assinaturas) | **Já existe** (`Recorrencia`, migrations 0002-0005) — implementação própria do Replit Agent, diferente da minha (usa `management/commands/gerar_recorrencias.py` em vez de geração preguiçosa via context processor) | ⬜ Revisar se funciona corretamente, não duplicar |
| Sistema de design (`brand.css`, paleta única) | **Não existe** — CSS morto (`all.css`, `calendar.css`, `fontawesome.min.css`, `simple-sidebar.css`) ainda presente | ⬜ Reaplicar depois de resolver o bug e a duplicação |
| Login sem estilo | Não verificado ainda | ⬜ Conferir |
| `.btn-fab` duplicado 4x | Provavelmente ainda duplicado (CSS não mudou) | ⬜ Conferir e consolidar |

---

## 📋 Plano desta sessão (ordem de execução)

1. ✅ Unificar `/transacoes-mes/`, `/transacoes/` e `/resumo-categoria/` em uma
   página só, corrigindo o bug da listagem no processo.
2. ✅ Testar (`manage.py check`, os 22 testes automatizados do projeto, e
   simulação de usuário logado criando/listando transações).
3. ✅ Gerar patch e atualizar este arquivo com o resultado.
4. ⬜ (Próxima sessão, se aprovado) Reaplicar sistema de design/CSS.

---

## ✅ Concluído nesta sessão (28/07/2026)

### Bug "transações do mês não listam" — CORRIGIDO
- Causa raiz confirmada: `/transacoes-mes/` nunca teve tabela de transações,
  só totais e gráficos. A lista real (`/transacoes/`, `TransacaoListView`)
  existia mas estava inacessível (link comentado no menu).
- **Correção:** `TransacaoListView.get_context_data()` (`cal/views/views_cbv.py`)
  agora também calcula os dados dos gráficos (reaproveitando
  `resumo_categorias_e_tipos()` de `cal/services.py`, sem duplicar lógica).
  `templates/cal/lista_transacoes.html` ganhou os cards de totais
  (entradas/saídas/saldo) e os 2 gráficos (por tipo, por categoria), além da
  lista que já tinha.

### Unificação das 3 páginas — CONCLUÍDA
- `/transacoes-mes/` (`transacoes_mes_view` em `cal/views/views_transacao.py`)
  agora é um `redirect('cal:listar_transacoes')`.
- `/resumo-categoria/` (`resumo_categoria_view` em `cal/views/views_cartao.py`)
  agora é um `redirect('cal:listar_transacoes')`.
- Templates órfãos removidos: `templates/cal/transacoes_mes.html`,
  `templates/cal/resumo_categoria.html`.
- Menu (`navbar.html`) e home (`home.html`) atualizados: um só link/botão
  "Despesas" apontando pra `listar_transacoes`; removidos "Despesas Filtro"
  (estava comentado/morto) e "Balanço Mensal" (duplicava o mesmo conteúdo).
  De brinde, corrigi uma tag `</li>` órfã que já existia na navbar.
- FAB (`base.html`) atualizado pra apontar direto pra `listar_transacoes`
  (evita um redirect a mais no fluxo mais usado do app).

### Validação
- `manage.py check`: sem problemas.
- **Os 22 testes automatizados do projeto continuam passando** (rodei
  `manage.py test cal` depois de todas as mudanças).
- Teste manual: criei um usuário + 2 transações do mês atual (uma com
  categoria, uma sem) e confirmei via `Client()` que ambas aparecem na
  listagem, os gráficos renderizam com `chartTipo`/`chartCategoria`, os
  redirects de `/transacoes-mes/` e `/resumo-categoria/` funcionam, e a home
  não mostra mais o botão duplicado.

### Arquivos alterados
```
cal/views/views_cbv.py          # TransacaoListView: + dados dos gráficos no contexto
cal/views/views_transacao.py    # transacoes_mes_view -> redirect
cal/views/views_cartao.py       # resumo_categoria_view -> redirect
templates/cal/lista_transacoes.html   # + totais + gráficos (unificado)
templates/cal/transacoes_mes.html     # REMOVIDO
templates/cal/resumo_categoria.html   # REMOVIDO
templates/navbar.html           # menu unificado, tag <li> órfã corrigida
templates/home.html             # botão duplicado removido
templates/base.html             # FAB aponta direto pra listar_transacoes
```
Patch: `unificacao_despesas.patch` (aplicar com `git apply` na raiz do projeto).

---

## 📋 Próximos passos sugeridos (não iniciados)

1. ⬜ Reaplicar o sistema de design (`brand.css`, paleta única, remoção de CSS
   morto: `all.css`, `calendar.css`, `fontawesome.min.css`,
   `simple-sidebar.css`) — nenhum desses arquivos foi tocado nesta sessão.
2. ⬜ Conferir se o modal de registro rápido (FAB) existe neste código; a
   `transacao_rapida` view existe (`cal/views/views_transacao.py`) mas não
   confirmei se o modal em `base.html` está completo/funcional aqui.
3. ⬜ Revisar a implementação de Recorrências deste código (usa
   `management/commands/gerar_recorrencias.py`, diferente da abordagem
   anterior) — só conferir se está funcionando, não recriar.
4. ⬜ `.btn-fab` duplicado (se ainda for o caso, não reconferido nesta sessão).
